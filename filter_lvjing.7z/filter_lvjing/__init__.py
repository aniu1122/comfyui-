from .filter_lvjing import FilterLvJingNode

NODE_CLASS_MAPPINGS = {
    "FilterLvJing": FilterLvJingNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "FilterLvJing": "滤镜lvjing——阿牛"
}

__all__ = ['NODE_CLASS_MAPPINGS', 'NODE_DISPLAY_NAME_MAPPINGS']