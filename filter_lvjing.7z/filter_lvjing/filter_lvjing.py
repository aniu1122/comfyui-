import torch
import numpy as np
from PIL import Image
from .filters import apply_filter

class FilterLvJingNode:
    def __init__(self):
        pass

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "image": ("IMAGE",),
                "filter_type": ([
                    "青橙色调", "复古胶片", "奶油色调", "暗黑风", "日系小清新",
                    "赛博朋克", "梦幻紫调", "森系绿调", "黄昏暖调", "冷白调",
                    "电影质感", "黑白高对比", "柔焦人像", "油画质感", "HDR增强",
                    "褪色回忆", "霓虹夜景", "极简灰调", "暖阳午后"
                ],),
            },
        }

    RETURN_TYPES = ("IMAGE",)
    FUNCTION = "apply_filter_node"
    CATEGORY = "image/filter"

    def apply_filter_node(self, image, filter_type):
        # Convert tensor to PIL Image
        image = Image.fromarray((image.squeeze().numpy() * 255).astype(np.uint8))
        
        # Apply the selected filter
        filtered_image = apply_filter(image, filter_type)
        
        # Convert back to tensor
        filtered_image = torch.from_numpy(np.array(filtered_image).astype(np.float32) / 255.0).unsqueeze(0)
        
        return (filtered_image,)