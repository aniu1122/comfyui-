from PIL import Image, ImageEnhance, ImageOps, ImageFilter
import numpy as np

def apply_filter(image, filter_type):
    if filter_type == "青橙色调":
        return qingcheng_tone(image)
    elif filter_type == "复古胶片":
        return vintage_film(image)
    elif filter_type == "奶油色调":
        return creamy_tone(image)
    elif filter_type == "暗黑风":
        return dark_mood(image)
    elif filter_type == "日系小清新":
        return japanese_style(image)
    elif filter_type == "赛博朋克":
        return cyberpunk(image)
    elif filter_type == "梦幻紫调":
        return dreamy_purple(image)
    elif filter_type == "森系绿调":
        return forest_green(image)
    elif filter_type == "黄昏暖调":
        return golden_hour(image)
    elif filter_type == "冷白调":
        return cold_white(image)
    elif filter_type == "电影质感":
        return cinematic(image)
    elif filter_type == "黑白高对比":
        return high_contrast_bw(image)
    elif filter_type == "柔焦人像":
        return soft_focus_portrait(image)
    elif filter_type == "油画质感":
        return oil_painting(image)
    elif filter_type == "HDR增强":
        return hdr_enhance(image)
    elif filter_type == "褪色回忆":
        return faded_memory(image)
    elif filter_type == "霓虹夜景":
        return neon_night(image)
    elif filter_type == "极简灰调":
        return minimal_gray(image)
    elif filter_type == "暖阳午后":
        return warm_afternoon(image)
    else:
        return image

def qingcheng_tone(image):
    """青橙色调，网红常用风格"""
    # 增加对比度
    enhancer = ImageEnhance.Contrast(image)
    image = enhancer.enhance(1.2)
    
    # 分离RGB通道
    r, g, b = image.split()
    
    # 增强红色和蓝色，减弱绿色
    r = r.point(lambda x: min(x + 50, 255))
    g = g.point(lambda x: max(x - 30, 0))
    b = b.point(lambda x: min(x + 30, 255))
    
    # 合并通道
    image = Image.merge("RGB", (r, g, b))
    
    # 调整饱和度
    enhancer = ImageEnhance.Color(image)
    image = enhancer.enhance(1.3)
    
    return image

def vintage_film(image):
    """复古胶片风格"""
    # 增加对比度
    enhancer = ImageEnhance.Contrast(image)
    image = enhancer.enhance(1.1)
    
    # 增加暖色调
    r, g, b = image.split()
    r = r.point(lambda x: min(x + 30, 255))
    b = b.point(lambda x: max(x - 20, 0))
    image = Image.merge("RGB", (r, g, b))
    
    # 添加颗粒感
    np_image = np.array(image)
    noise = np.random.normal(0, 10, np_image.shape).astype(np.uint8)
    np_image = np.clip(np_image + noise, 0, 255)
    image = Image.fromarray(np_image)
    
    return image

def creamy_tone(image):
    """奶油色调，柔和风格"""
    # 降低对比度
    enhancer = ImageEnhance.Contrast(image)
    image = enhancer.enhance(0.8)
    
    # 增加亮度
    enhancer = ImageEnhance.Brightness(image)
    image = enhancer.enhance(1.2)
    
    # 添加暖色调
    r, g, b = image.split()
    r = r.point(lambda x: min(x + 20, 255))
    b = b.point(lambda x: max(x - 10, 0))
    image = Image.merge("RGB", (r, g, b))
    
    return image

def dark_mood(image):
    """暗黑风格，高对比度"""
    # 增加对比度
    enhancer = ImageEnhance.Contrast(image)
    image = enhancer.enhance(1.5)
    
    # 降低亮度
    enhancer = ImageEnhance.Brightness(image)
    image = enhancer.enhance(0.7)
    
    # 增加冷色调
    r, g, b = image.split()
    b = b.point(lambda x: min(x + 30, 255))
    r = r.point(lambda x: max(x - 20, 0))
    image = Image.merge("RGB", (r, g, b))
    
    return image

def japanese_style(image):
    """日系小清新风格"""
    # 降低对比度
    enhancer = ImageEnhance.Contrast(image)
    image = enhancer.enhance(0.9)
    
    # 增加亮度
    enhancer = ImageEnhance.Brightness(image)
    image = enhancer.enhance(1.3)
    
    # 降低饱和度
    enhancer = ImageEnhance.Color(image)
    image = enhancer.enhance(0.8)
    
    return image

def cyberpunk(image):
    """赛博朋克风格"""
    # 增强对比度
    enhancer = ImageEnhance.Contrast(image)
    image = enhancer.enhance(1.4)
    
    # 调整色调（偏蓝紫）
    r, g, b = image.split()
    r = r.point(lambda x: max(x - 50, 0))
    g = g.point(lambda x: max(x - 20, 0))
    b = b.point(lambda x: min(x + 50, 255))
    image = Image.merge("RGB", (r, g, b))
    
    # 增加锐化
    image = image.filter(ImageFilter.SHARPEN)
    
    return image

def dreamy_purple(image):
    """梦幻紫调"""
    # 降低对比度
    enhancer = ImageEnhance.Contrast(image)
    image = enhancer.enhance(0.9)
    
    # 增加紫色调
    r, g, b = image.split()
    r = r.point(lambda x: min(x + 30, 255))
    b = b.point(lambda x: min(x + 50, 255))
    image = Image.merge("RGB", (r, g, b))
    
    # 添加柔焦效果
    image = image.filter(ImageFilter.GaussianBlur(radius=1))
    
    return image

def forest_green(image):
    """森系绿调"""
    # 增强绿色调
    r, g, b = image.split()
    g = g.point(lambda x: min(x + 50, 255))
    b = b.point(lambda x: max(x - 20, 0))
    image = Image.merge("RGB", (r, g, b))
    
    # 增加对比度
    enhancer = ImageEnhance.Contrast(image)
    image = enhancer.enhance(1.2)
    
    return image

def golden_hour(image):
    """黄昏暖调"""
    # 增加暖色调
    r, g, b = image.split()
    r = r.point(lambda x: min(x + 50, 255))
    b = b.point(lambda x: max(x - 30, 0))
    image = Image.merge("RGB", (r, g, b))
    
    # 降低对比度
    enhancer = ImageEnhance.Contrast(image)
    image = enhancer.enhance(0.9)
    
    return image

def cold_white(image):
    """冷白调"""
    # 增加冷色调
    r, g, b = image.split()
    b = b.point(lambda x: min(x + 30, 255))
    r = r.point(lambda x: max(x - 20, 0))
    image = Image.merge("RGB", (r, g, b))
    
    # 增加亮度
    enhancer = ImageEnhance.Brightness(image)
    image = enhancer.enhance(1.2)
    
    return image

def cinematic(image):
    """电影质感"""
    # 增加对比度
    enhancer = ImageEnhance.Contrast(image)
    image = enhancer.enhance(1.3)
    
    # 降低饱和度
    enhancer = ImageEnhance.Color(image)
    image = enhancer.enhance(0.7)
    
    # 添加暗角效果
    width, height = image.size
    mask = Image.new("L", (width, height), 255)
    for y in range(height):
        for x in range(width):
            distance = ((x - width / 2) ** 2 + (y - height / 2) ** 2) ** 0.5
            mask.putpixel((x, y), int(255 - distance * 0.1))
    image = Image.composite(image, Image.new("RGB", (width, height), (0, 0, 0)), mask)
    
    return image

def high_contrast_bw(image):
    """黑白高对比"""
    # 转换为黑白
    image = image.convert("L")
    
    # 增加对比度
    enhancer = ImageEnhance.Contrast(image)
    image = enhancer.enhance(2.0)
    
    return image

def soft_focus_portrait(image):
    """柔焦人像"""
    # 添加柔焦效果
    image = image.filter(ImageFilter.GaussianBlur(radius=2))
    
    # 增加亮度
    enhancer = ImageEnhance.Brightness(image)
    image = enhancer.enhance(1.1)
    
    return image

def oil_painting(image):
    """油画质感"""
    # 添加油画效果
    image = image.filter(ImageFilter.SMOOTH_MORE)
    image = image.filter(ImageFilter.EMBOSS)
    
    return image

def hdr_enhance(image):
    """HDR增强"""
    # 增加对比度
    enhancer = ImageEnhance.Contrast(image)
    image = enhancer.enhance(1.5)
    
    # 增加饱和度
    enhancer = ImageEnhance.Color(image)
    image = enhancer.enhance(1.4)
    
    return image

def faded_memory(image):
    """褪色回忆"""
    # 降低饱和度
    enhancer = ImageEnhance.Color(image)
    image = enhancer.enhance(0.5)
    
    # 增加亮度
    enhancer = ImageEnhance.Brightness(image)
    image = enhancer.enhance(1.2)
    
    return image

def neon_night(image):
    """霓虹夜景"""
    # 增强对比度
    enhancer = ImageEnhance.Contrast(image)
    image = enhancer.enhance(1.6)
    
    # 调整色调（偏蓝紫）
    r, g, b = image.split()
    r = r.point(lambda x: max(x - 50, 0))
    b = b.point(lambda x: min(x + 50, 255))
    image = Image.merge("RGB", (r, g, b))
    
    return image

def minimal_gray(image):
    """极简灰调"""
    # 降低饱和度
    enhancer = ImageEnhance.Color(image)
    image = enhancer.enhance(0.3)
    
    # 增加对比度
    enhancer = ImageEnhance.Contrast(image)
    image = enhancer.enhance(1.2)
    
    return image

def warm_afternoon(image):
    """暖阳午后"""
    # 增加暖色调
    r, g, b = image.split()
    r = r.point(lambda x: min(x + 40, 255))
    b = b.point(lambda x: max(x - 20, 0))
    image = Image.merge("RGB", (r, g, b))
    
    # 降低对比度
    enhancer = ImageEnhance.Contrast(image)
    image = enhancer.enhance(0.9)
    
    return image